import TeamUpLanding from "../components/TeamUpLanding";

export default function Home() {
  return <TeamUpLanding />;
}
